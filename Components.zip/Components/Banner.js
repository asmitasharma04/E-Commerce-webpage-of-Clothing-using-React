import React from 'react';

// Import images
import bershka from './Assets/BERSHKA.png';
import bonkers from './Assets/bonkers.png';
import calvinKlein from './Assets/CALVIN KLEIN.png';
import diesel from './Assets/DIESEL.png';
import everlane from './Assets/EVERLANE.png';
import gap from './Assets/GAP.png';
import gucci from './Assets/GUCCI.png';
import hm from './Assets/H &M.png';
import prada from './Assets/PRADA.png';
import versace from './Assets/VERSACE.png';
import valentino from './Assets/valentino.png';
import zara from './Assets/ZARA.png';
import vogue from './Assets/VOGUE.png';

function Banner() {
  const brands = [
    bershka,
    bonkers,
    calvinKlein,
    diesel,
    everlane,
    gap,
    gucci,
    hm,
    prada,
    versace,
    valentino,
    zara,
    vogue,
  ];

  return (
    <section className="banner">
      <div className="banner__container">
        {brands.map((brand, index) => (
          <img key={index} src={brand} alt={`Brand ${index + 1}`} />
        ))}
      </div>
    </section>
  );
}

export default Banner;
