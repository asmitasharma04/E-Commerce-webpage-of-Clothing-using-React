import React, { useEffect } from 'react';
// import './App.css'; // Ensure to import your CSS here

const Blog = () => {
    const blogPosts = [
        {
            id: 'blog1',
            description: "As the temperature rises, it's time to refresh your wardrobe with lightweight fabrics,...",
        },
        {
            id: 'blog2',
            description: "Finding the perfect dress starts with understanding what flatters your unique body shape...",
        },
        {
            id: 'blog3',
            description: "Refresh your wardrobe with bold prints and vibrant colors this summer.....",
        },
        {
            id: 'blog4',
            description: "We love seeing how our customers make our pieces their own! Here are some of our favorite looks...",
        },
    ];

    useEffect(() => {
        const cards = document.querySelectorAll('.card');

        // Ensure at least one card is selected initially
        let selectedCard = document.querySelector('.card.selected');
        if (!selectedCard && cards.length > 0) {
            selectedCard = cards[0];
            selectedCard.classList.add('selected');
        }

        const handleClick = (event) => {
            // Remove 'selected' class from all cards
            cards.forEach(card => card.classList.remove('selected'));
            // Add 'selected' class to the clicked card
            event.currentTarget.classList.add('selected');
        };

        cards.forEach(card => {
            card.addEventListener('click', handleClick);
        });

        const readMoreButtons = document.querySelectorAll('.read-more');
        const handleReadMoreClick = (e) => {
            e.stopPropagation(); // Prevent the click from bubbling up to the card
            alert('Navigating to the full blog post...');
            // Simulate navigation
        };

        readMoreButtons.forEach(button => {
            button.addEventListener('click', handleReadMoreClick);
        });

        // Cleanup function to remove event listeners
        return () => {
            cards.forEach(card => {
                card.removeEventListener('click', handleClick);
            });
            readMoreButtons.forEach(button => {
                button.removeEventListener('click', handleReadMoreClick);
            });
        };
    }, []); // Empty dependency array ensures this runs once after the initial render

    return (
        <div id="wrapper" className="wrapper">
            <br>
            </br>
            <br></br>
            <h2 style={{ color: '#588C7E', textAlign: 'center', fontStyle: 'bodoni' }}>Blog Page</h2>
            <br></br>
            <div className="container">
                {blogPosts.map((post, index) => (
                    <label key={post.id} className="card" data-id={post.id} for={post.id}>
                        <div className="row">
                            <div className="icon">{index + 1}</div>
                            <div className="description">
                                <p>{post.description}</p>
                                <button className="read-more">Read More</button>
                            </div>
                        </div>
                    </label>
                ))}
            </div>
        </div>
    );
};

export default Blog;