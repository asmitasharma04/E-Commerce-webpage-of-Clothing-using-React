// import React, { useContext } from 'react';
// import { ShopContext } from '../../Context/ShopContext';
// import { useNavigate } from 'react-router-dom';  // Import useNavigate
// import remove_icon from '../Assets/cart_cross_icon.png';
// import './CartItems.css';

// const CartItems = () => {
//   const { getTotalCartAmount, all_product, cartItems, removeFromCart, updateCartQuantity } = useContext(ShopContext);
//   const navigate = useNavigate();  // Initialize the navigate function

//   // Handle proceed to checkout navigation
//   const handleProceedToCheckout = () => {
//     navigate('/payment');  // Navigate to the payment page
//   };

//   // Function to handle quantity change (increase or decrease)
//   const handleQuantityChange = (productId, action) => {
//     if (action === 'increase') {
//       updateCartQuantity(productId, cartItems[productId] + 1);  // Increase quantity
//     } else if (action === 'decrease') {
//       if (cartItems[productId] > 1) {
//         updateCartQuantity(productId, cartItems[productId] - 1);  // Decrease quantity but prevent going below 1
//       }
//     }
//   };

//   return (
//     <div className="cartitems">
//       {/* Cart Header */}
//       <div className="cartitems-format-main">
//         <p>Products</p>
//         <p>Title</p>
//         <p>Price</p>
//         <p>Quantity</p>
//         <p>Total</p>
//         <p>Remove</p>
//       </div>
//       <hr />
      
//       {/* Loop through all products and show items in cart */}
//       {all_product.map((product) => {
//         if (cartItems[product.id] > 0) {
//           const total = product.new_price * cartItems[product.id];  // Calculate total for the item
//           return (
//             <div key={product.id}>
//               <div className="cartitems-format cartitems-format-main">
//                 {/* Product image and details */}
//                 <img src={product.image} alt={product.name} className="carticon-product-icon" />
//                 <p>{product.name}</p>
//                 <p>Rs.{product.new_price}</p>
                
//                 {/* Quantity buttons (Increase and Decrease) */}
//                 <div className="cartitems-quantity-buttons">
//                   <button 
//                     className="cartitems-quantity-decrease" 
//                     onClick={() => handleQuantityChange(product.id, 'decrease')} 
//                     disabled={cartItems[product.id] <= 1} // Disable decrease if quantity is 1
//                   >
//                     -
//                   </button>
//                   <button className="cartitems-quantity">{cartItems[product.id]}</button>
//                   <button 
//                     className="cartitems-quantity-increase" 
//                     onClick={() => handleQuantityChange(product.id, 'increase')}
//                   >
//                     +
//                   </button>
//                 </div>
                
//                 {/* Total cost for this product */}
//                 <p>Rs.{total}</p>
                
//                 {/* Remove icon */}
//                 <img 
//                   className="cartitems-remove-icon" 
//                   src={remove_icon} 
//                   onClick={() => removeFromCart(product.id)} 
//                   alt="Remove" 
//                 />
//               </div>
//               <hr />
//             </div>
//           );
//         }
//         return null;
//       })}

//       {/* Cart totals and checkout */}
//       <div className="cartitems-down">
//         <div className="cartitems-total">
//           <h1>Cart Totals</h1>
//           <div>
//             <div className="cartitems-total-item">
//               <p>Subtotal</p>
//               <p>Rs.{getTotalCartAmount()}</p>
//             </div>
//             <hr />
//             <div className="cartitems-total-item">
//               <p>Shipping Fee</p>
//               <p>Free</p>
//             </div>
//             <hr />
//             <div className="cartitems-total-item">
//               <h3>Total</h3>
//               <h3>Rs.{getTotalCartAmount()}</h3> {/* Fixed currency symbol */}
//             </div>
//           </div>
//           {/* Checkout Button */}
//           <button onClick={handleProceedToCheckout}>PROCEED TO CHECKOUT</button>
//         </div>

//         {/* Promo code section */}
//         <div className="cartitems-promocode">
//           <p>If you have a promo code, enter it here</p>
//           <div className="cartitems-promobox">
//             <input type="text" placeholder="promo code" />
//             <button>Submit</button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CartItems;

// import React, { useContext } from 'react';
// import { ShopContext } from '../../Context/ShopContext';
// import { useNavigate } from 'react-router-dom';
// import remove_icon from '../Assets/cart_cross_icon.png';
// import './CartItems.css';

// const CartItems = () => {
//   const { getTotalCartAmount, all_product, cartItems, removeFromCart, updateCartQuantity } = useContext(ShopContext);
//   const navigate = useNavigate();

//   const handleProceedToCheckout = () => {
//     navigate('/payment');
//   };

//   const handleQuantityChange = (productId, action) => {
//     if (action === 'increase') {
//       updateCartQuantity(productId, cartItems[productId] + 1);
//     } else if (action === 'decrease') {
//       if (cartItems[productId] > 1) {
//         updateCartQuantity(productId, cartItems[productId] - 1);
//       }
//     }
//   };

//   return (
//     <div className="cartitems">
//       <div className="cartitems-format-main">
//         <p>Products</p>
//         <p>Title</p>
//         <p>Price</p>
//         <p>Quantity</p>
//         <p>Total</p>
//         <p>Remove</p>
//       </div>
//       <hr />
      
//       {all_product.map((product) => {
//         if (cartItems[product.id] > 0) {
//           const total = product.new_price * cartItems[product.id];
//           return (
//             <div key={product.id}>
//               <div className="cartitems-format cartitems-format-main">
//                 <img src={product.image} alt={product.name} className="carticon-product-icon" />
//                 <p>{product.name}</p>
//                 <p>Rs.{product.new_price}</p>
                
//                 <div className="cartitems-quantity-buttons">
//                   <button 
//                     className="cartitems-quantity-decrease" 
//                     onClick={() => handleQuantityChange(product.id, 'decrease')} 
//                     disabled={cartItems[product.id] <= 1}
//                   >
//                     -
//                   </button>
//                   <span className="cartitems-quantity">{cartItems[product.id]}</span>
//                   <button 
//                     className="cartitems-quantity-increase" 
//                     onClick={() => handleQuantityChange(product.id, 'increase')}
//                   >
//                     +
//                   </button>
//                 </div>
                
//                 <p>Rs.{total}</p>
                
//                 <img 
//                   className="cartitems-remove-icon" 
//                   src={remove_icon} 
//                   onClick={() => removeFromCart(product.id)} 
//                   alt="Remove" 
//                 />
//               </div>
//               <hr />
//             </div>
//           );
//         }
//         return null;
//       })}

//       <div className="cartitems-down">
//         <div className="cartitems-total">
//           <h1>Cart Totals</h1>
//           <div>
//             <div className="cartitems-total-item">
//               <p>Subtotal</p>
//               <p>Rs.{getTotalCartAmount()}</p>
//             </div>
//             <hr />
//             <div className="cartitems-total-item">
//               <p>Shipping Fee</p>
//               <p>Free</p>
//             </div>
//             <hr />
//             <div className="cartitems-total-item">
//               <h3>Total</h3>
//               <h3>Rs.{getTotalCartAmount()}</h3>
//             </div>
//           </div>
//           <button onClick={handleProceedToCheckout}>PROCEED TO CHECKOUT</button>
//         </div>

//         <div className="cartitems-promocode">
//           <p>If you have a promo code, enter it here</p>
//           <div className="cartitems-promobox">
//             <input type="text" placeholder="promo code" />
//             <button>Submit</button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CartItems;








































import React, { useContext } from 'react';
import { ShopContext } from '../../Context/ShopContext';
import { useNavigate } from 'react-router-dom';  // Import useNavigate
import remove_icon from '../Assets/cart_cross_icon.png';
import './CartItems.css';

const CartItems = () => {
  const { getTotalCartAmount, all_product, cartItems, removeFromCart, updateCartQuantity } = useContext(ShopContext);
  const navigate = useNavigate();  // Initialize the navigate function

  // Handle proceed to checkout navigation
  const handleProceedToCheckout = () => {
    navigate('/payment');  // Navigate to the payment page
  };

  // Function to handle quantity change (increase or decrease)
  const handleQuantityChange = (productId, action) => {
    if (action === 'increase') {
      updateCartQuantity(productId, cartItems[productId] + 1);  // Increase quantity
    } else if (action === 'decrease') {
      if (cartItems[productId] > 1) {
        updateCartQuantity(productId, cartItems[productId] - 1);  // Decrease quantity but prevent going below 1
      }
    }
  };

  return (
    <div className="cartitems">
      {/* Cart Header */}
      <div className="cartitems-format-main">
        <p>Products</p>
        <p>Title</p>
        <p>Price</p>
        <p>Quantity</p>
        <p>Total</p>
        <p>Remove</p>
      </div>
      <hr />
      
      {/* Loop through all products and show items in cart */}
      {all_product.map((product) => {
        if (cartItems[product.id] > 0) {
          const total = product.new_price * cartItems[product.id];  // Calculate total for the item
          return (
            <div key={product.id}>
              <div className="cartitems-format cartitems-format-main">
                {/* Product image and details */}
                <img src={product.image} alt={product.name} className="carticon-product-icon" />
                <p>{product.name}</p>
                <p>Rs.{product.new_price}</p>
                
                {/* Quantity buttons (Increase and Decrease) */}
                <div className="cartitems-quantity-buttons">
                  {/* <button 
                    className="cartitems-quantity-decrease" 
                    onClick={() => handleQuantityChange(product.id, 'decrease')} 
                    disabled={cartItems[product.id] <= 1} // Disable decrease if quantity is 1
                  >
                    -
                  </button> */}
                  <button className="cartitems-quantity">{cartItems[product.id]}</button>
                  {/* <button 
                    className="cartitems-quantity-increase" 
                    onClick={() => handleQuantityChange(product.id, 'increase')}
                  >
                    +
                  </button> */}
                </div>
                
                {/* Total cost for this product */}
                <p>Rs.{total}</p>
                
                {/* Remove icon */}
                <img 
                  className="cartitems-remove-icon" 
                  src={remove_icon} 
                  onClick={() => removeFromCart(product.id)} 
                  alt="Remove" 
                />
              </div>
              <hr />
            </div>
          );
        }
        return null;
      })}

      {/* Cart totals and checkout */}
      <div className="cartitems-down">
        <div className="cartitems-total">
          <h1>Cart Totals</h1>
          <div>
            <div className="cartitems-total-item">
              <p>Subtotal</p>
              <p>Rs.{getTotalCartAmount()}</p>
            </div>
            <hr />
            <div className="cartitems-total-item">
              <p>Shipping Fee</p>
              <p>Free</p>
            </div>
            <hr />
            <div className="cartitems-total-item">
              <h3>Total</h3>
              <h3>Rs.{getTotalCartAmount()}</h3> {/* Fixed currency symbol */}
            </div>
          </div>
          {/* Checkout Button */}
          <button onClick={handleProceedToCheckout}>PROCEED TO CHECKOUT</button>
        </div>

        {/* Promo code section */}
        <div className="cartitems-promocode">
          <p>If you have a promo code, enter it here</p>
          <div className="cartitems-promobox">
            <input type="text" placeholder="promo code" />
            <button>Submit</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItems; 