import React, { useState } from 'react';
import emailjs from 'emailjs-com'; // Ensure this package is installed

const Chatbot = () => {
    const [userInput, setUserInput] = useState('');
    const [messages, setMessages] = useState([{ text: 'Hello! How can I assist you with fashion today?', type: 'bot' }]);

    const sendMessage = () => {
        if (userInput.trim() === '') return;

        const userMessage = { text: userInput, type: 'user' };
        setMessages([...messages, userMessage]);
        setUserInput('');

        // Bot response logic
        setTimeout(() => {
            const botResponse = getBotResponse(userInput);
            const botMessage = { text: botResponse, type: 'bot' };
            setMessages(prevMessages => [...prevMessages, botMessage]);
        }, 500);

        // Optional: Send user message via email
        // emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', {
        //     user_message: userInput,
        // }).then(response => {
        //     console.log('SUCCESS!', response.status, response.text);
        // }).catch(err => {
        //     console.error('FAILED...', err);
        // });
    };

    const getBotResponse = (input) => {
        const lowerCaseInput = input.toLowerCase();

        // Predefined responses
        if (lowerCaseInput.includes("color")) {
            return "The trending colors this season are vibrant hues like neon green, bold blue, and soft pastels.";
        } else if (lowerCaseInput.includes("traditional")) {
            return "For traditional wear, sarees, lehengas, and salwar kameez in rich fabrics and intricate designs are perfect choices.";
        } else if (lowerCaseInput.includes("party")) {
            return "For parties, you can't go wrong with a little black dress, sequined outfits, or elegant gowns.";
        } else if (lowerCaseInput.includes("path")) {
            return "For a path or religious ceremony, opt for modest and comfortable attire such as a simple kurti with leggings or a churidar.";
        } else if (lowerCaseInput.includes("fashion")) {
            return "The current fashion trends include oversized blazers, bold prints, and pastel colors.";
        } else if (lowerCaseInput.includes("help")) {
            return "I'm here to help! Ask me about fashion trends or anything else related to clothing.";
        } else {
            return "Sorry, I didn't understand that. Can you please rephrase?";
        }
    };

    return (
        <div className="chatbot">
            <center>
                <h1>Want to Chat...??</h1>
                <img 
                    src="https://cdn.shopify.com/s/files/1/1061/1924/products/Robot_Emoji_Icon_abe1111a-1293-4668-bdf9-9ceb05cff58e_grande.png?v=1571606090" 
                    width="100" 
                    height="100" 
                    alt="Chatbot" 
                />
                <h1>"Have a question? I'm here to answer."</h1>
            </center>
            <div className="chat-header">
                <span>Fashion Chatbot</span>
                <button className="close-btn" onClick={() => console.log('Close chat')}>X</button>
            </div>
            <div className="chat-box" id="chat-box">
                {messages.map((msg, index) => (
                    <div key={index} className={`${msg.type}-message`}>
                        {msg.text}
                    </div>
                ))}
            </div>
            <div className="input-box">
                <input
                    type="text"
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder="Type your message..."
                />
                <button onClick={sendMessage}>Send</button>
            </div>
        </div>
    );
};

export default Chatbot;
