import React, { useEffect } from 'react';
import emailjs from 'emailjs-com';
import contactImage from './Assets/GIF.gif'; // Adjust the path to your actual image location
// import './Contact.css';

const Contact = () => {
    useEffect(() => {
        // Initialize EmailJS with your user ID
        emailjs.init('PjknCrMGnObtGFs1o'); // Replace 'YOUR_USER_ID' with your actual user ID from EmailJS

        const form = document.getElementById('contact-form');
        
        const handleSubmit = (event) => {
            event.preventDefault();

            // Collect form data
            const params = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                subject: document.getElementById('subject').value,
                message: document.getElementById('message').value
            };

            // EmailJS service and template IDs
            const serviceID = 'service_oq8x5og'; // Replace with your actual Service ID
            const templateID = 'template_kjcb4lg'; // Replace with your actual Template ID

            // Send email
            emailjs.send(serviceID, templateID, params)
                .then((response) => {
                    console.log('SUCCESS!', response.status, response.text);
                    alert('Your message has been sent successfully!');
                    // Clear form fields
                    form.reset();
                }, (error) => {
                    console.error('FAILED...', error);
                    alert('Failed to send your message. Please try again later.');
                });
        };

        form.addEventListener('submit', handleSubmit);

        // Cleanup function to remove event listener
        return () => {
            form.removeEventListener('submit', handleSubmit);
        };
    }, []);

    return (
        <section className="contact" id="contact">
            <h1 className="heading"><span>Contact</span> Us </h1>
            <div className="row">
                <div className="image">
                    <img src={contactImage} alt="Contact Us" />
                </div>
                <form id="contact-form">
                    <h3>Get in touch</h3>
                    <div className="inputBox">
                        <input type="text" id="name" placeholder="Your name" required />
                    </div>
                    <div className="inputBox">
                        <input type="email" id="email" placeholder="Your email" required />
                    </div>
                    <div className="inputBox">
                        <input type="text" id="subject" placeholder="Subject" required />
                    </div>
                    <textarea id="message" placeholder="Your message" required></textarea>
                    <input type="submit" value="Send Message" className="btn" />
                </form>
            </div>
        </section>
    );
};

export default Contact;