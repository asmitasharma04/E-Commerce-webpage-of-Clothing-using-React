import React, { useState } from 'react';

const CustomerReviews = () => {
  // State to manage the reviews
  const [reviews, setReviews] = useState([
    {
      name: "Alice Johnson",
      book: "The Great Adventure",
      review: "This book was an amazing read! I couldn't put it down.",
      image: "https://randomuser.me/api/portraits/women/1.jpg"
    },
    {
      name: "Bob Smith",
      book: "Learning Bootstrap",
      review: "A great insight into the subject. Highly recommend!",
      image: "https://randomuser.me/api/portraits/men/1.jpg"
    },
    {
      name: "Charlie Brown",
      book: "Inspiring Stories",
      review: "An inspiring story that really resonated with me.",
      image: "https://randomuser.me/api/portraits/men/2.jpg"
    }
  ]);

  // Function to handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    
    const name = event.target.name.value;
    const book = event.target.book.value;
    const review = event.target.review.value;

    if (name && book && review) {
      const newReview = {
        name,
        book,
        review,
        image: "https://randomuser.me/api/portraits/men/3.jpg" // Default image for new reviews
      };
      
      // Add the new review to the state
      setReviews((prevReviews) => [...prevReviews, newReview]);
      
      // Reset form after submission
      event.target.reset();
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center">Customer Reviews</h1>

      <div id="reviewCarousel" className="carousel slide mt-4" data-ride="carousel" data-interval="3000">
        <div className="carousel-inner">
          {reviews.map((review, index) => (
            <div key={index} className={`carousel-item ${index === 0 ? 'active' : ''}`}>
              <div className="review-card">
                <img src={review.image} alt={review.name} className="review-image" />
                <h5>{review.name}</h5>
                <h6 className="text-muted">{review.book}</h6>
                <p>{review.review}</p>
              </div>
            </div>
          ))}
        </div>
        <a className="carousel-control-prev" href="#reviewCarousel" role="button" data-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="sr-only">Previous</span>
        </a>
        <a className="carousel-control-next" href="#reviewCarousel" role="button" data-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="sr-only">Next</span>
        </a>
      </div>

      <div className="submit-section mt-4">
        <h2 className="text-center">Submit Your Review</h2>
        <div className="form-box">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Your Name</label>
              <input type="text" className="form-control form-control-sm" id="name" placeholder="Enter Your Name" required />
            </div>
            <div className="form-group">
              <label htmlFor="book">Book Title</label>
              <input type="text" className="form-control form-control-sm" id="book" placeholder="Enter the Book Title" required />
            </div>
            <div className="form-group">
              <label htmlFor="review">Your Review</label>
              <textarea className="form-control form-control-sm" id="review" rows="4" placeholder="Enter Your Review" required></textarea>
            </div>
            <button type="submit" className="btn btn-light btn-block">Submit</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CustomerReviews;
