// import React from 'react'
// import './Footer.css'
// import footer_logo from '../Assets/logo_big.png'
// import instagram_icon from '../Assets/instagram_icon.png'
// import pintester_icon from '../Assets/pintester_icon.png'
// import whatsapp_icon from '../Assets/whatsapp_icon.png'

// const Footer = () => {
//   return (
//     <div className='footer'>
//       <div className="footer-logo">
//         <img src={footer_logo} alt="" />
//         <p>SHOPPER</p>
//       </div>
//       <ul className="footer-links">
//         <li>Company</li>
//         <li>Products</li>
//         <li>Offices</li>
//         <li>About</li>
//         <li>Contact</li>
//       </ul>
//       <div className="footer-social-icon">
//         <div className="footer-icons-container">
//             <img src={instagram_icon} alt="" />
//         </div>
//         <div className="footer-icons-container">
//             <img src={pintester_icon} alt="" />
//         </div>
//         <div className="footer-icons-container">
//             <img src={whatsapp_icon} alt="" />
//         </div>
//       </div>
//       <div className="footer-copyright">
//         <hr />
//         <p>Copyright @ 2023 - All Right Reserved.</p>
//       </div>
//     </div>
//   )
// }

// export default Footer








import React, { useEffect } from 'react';
import './Footer.css';

function Footer() {
  useEffect(() => {
    const toggleButton = document.getElementById('toggleSocialMedia');
    if (toggleButton) {
      toggleButton.addEventListener('click', function() {
        const shareDiv = this.nextElementSibling.nextElementSibling;
        if (shareDiv) {
          shareDiv.style.display = shareDiv.style.display === 'none' || shareDiv.style.display === '' ? 'block' : 'none';
        } else {
          console.error('Share div not found.');
        }
      });
    }

    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();

        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);

        if (targetElement) {
          targetElement.scrollIntoView({ behavior: 'smooth' });
        } else {
          console.error('Target element not found for ID:', targetId);
        }
      });
    });

    return () => {
      if (toggleButton) {
        toggleButton.removeEventListener('click', () => {});
      }
      navLinks.forEach(anchor => {
        anchor.removeEventListener('click', () => {});
      });
    };
  }, []);

  return (
    <section className="footer">
      <div className="box-container1">
        <div className="box21">
          <h3 id="toggleSocialMedia">
            <i className="fas fa-bag-shopping"></i> Urban Trends
          </h3>
          <p>
            "Experience the perfect blend of comfort and style with our exclusive urban wear."
          </p>
          <div className="share hidden">
            <a href="#" className="fab fa-facebook-f"></a>
            <a href="#" className="fab fa-twitter"></a>
            <a href="#" className="fab fa-instagram"></a>
            <a href="#" className="fab fa-linkedin"></a>
          </div>
        </div>

        <div className="box21">
          <h3>Quick Links</h3>
          <a href="#" className="link">
            <i className="fas fa-arrow-right"></i> Home
          </a>
          <a href="#popular" className="link">
            <i className="fas fa-arrow-right"></i> Popular in women
          </a>
          <a href="#special" className="link">
            <i className="fas fa-arrow-right"></i> Sale
          </a>
          <a href="#wrapper" className="link">
            <i className="fas fa-arrow-right"></i> Blogs
          </a>
          <a href="#contact" className="link">
            <i className="fas fa-arrow-right"></i> Contact
          </a>
        </div>

        <div className="box21">
          <h3>Useful Links</h3>
          <a href="#" className="link">
            <i className="fas fa-arrow-right"></i> Help Center
          </a>
          <a href="#" className="link">
            <i className="fas fa-arrow-right"></i> Ask Questions
          </a>
          <a href="#" className="link">
            <i className="fas fa-arrow-right"></i> Send Feedback
          </a>
          <a href="#" className="link">
            <i className="fas fa-arrow-right"></i> Privacy Policy
          </a>
          <a href="#" className="link">
            <i className="fas fa-arrow-right"></i> Terms of Use
          </a>
        </div>
      </div>
      <div className="credit">
        Copyright &copy; <span>2024</span> by <span>Urban Trends</span> | All rights reserved
      </div>
    </section>
  );
}

export default Footer;
