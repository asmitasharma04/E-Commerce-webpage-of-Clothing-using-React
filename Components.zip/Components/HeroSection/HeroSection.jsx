import React, { useEffect } from 'react';

import fashionImage from '../Assets/front_page.png'; 
import './HeroSection.css';
 // Adjust according to the correct path
// Ensure the path is correct

function HeroSection() {
  useEffect(() => {
    const lines = document.querySelectorAll('.line');
    lines.forEach((line, index) => {
      setTimeout(() => {
        line.classList.add('visible');
      }, index * 1000); // Delay before each line appears
    });
  }, []); // Empty dependency array ensures this runs only once after the component mounts

  return (
    <div className="content">
      <div className="text-container">
        <h1 className="line">Welcome to Our Fashion Store</h1>
        <p className="line">"Fashion is the armor to survive the reality of everyday life."</p>
        <p className="line">"Style is a way to say who you are without having to speak."</p>
        <p className="line">"Fashion fades, only style remains the same."</p>
      </div>
      <div className="image-container">
        <img src={fashionImage} alt="Fashion Store" height="400px" /> {/* Adjust height as needed */}
      </div>
    </div>
  );
}

export default HeroSection;
