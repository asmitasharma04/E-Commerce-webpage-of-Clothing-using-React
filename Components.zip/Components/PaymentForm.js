

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './PaymentForm.css';

const PaymentForm = () => {
  const [billingDetails, setBillingDetails] = useState({
    fullName: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
  });

  const [paymentDetails, setPaymentDetails] = useState({
    cardNumber: '',
    expMonth: '',
    expYear: '',
    cvv: '',
  });

  const navigate = useNavigate(); // Initialize useNavigate

  const handleBillingChange = (e) => {
    const { name, value } = e.target;
    setBillingDetails((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePaymentChange = (e) => {
    const { name, value } = e.target;
    setPaymentDetails((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic
    alert('Proceeding to Checkout...');
    navigate('/'); // Redirect to the main page
  };

  return (
    <header>
      <div className="container">
        <div className="left">
          <h3>BILLING ADDRESS</h3>
          <form onSubmit={handleSubmit}>
            <label>
              Full name
              <input
                type="text"
                name="fullName"
                placeholder="Enter name"
                value={billingDetails.fullName}
                onChange={handleBillingChange}
              />
            </label>
            {/* <label>
              Email
              <input
                type="email"
                name="email"
                placeholder="Enter email"
                value={billingDetails.email}
                onChange={handleBillingChange}
              />
            </label> */}
            <label>
              Address
              <input
                type="text"
                name="address"
                placeholder="Enter address"
                value={billingDetails.address}
                onChange={handleBillingChange}
              />
            </label>
            <label>
              City
              <input
                type="text"
                name="city"
                placeholder="Enter City"
                value={billingDetails.city}
                onChange={handleBillingChange}
              />
            </label>
            <div id="zip">
              <label>
                State
                <select
                  name="state"
                  value={billingDetails.state}
                  onChange={handleBillingChange}
                >
                  <option>Choose State..</option>
                  <option>Rajasthan</option>
                  <option>Hariyana</option>
                  <option>Uttar Pradesh</option>
                  <option>Punjab</option>
                </select>
              </label>
              {/* <label>
                Zip code
                <input
                  type="number"
                  name="zipCode"
                  placeholder="Zip code"
                  value={billingDetails.zipCode}
                  onChange={handleBillingChange}
                />
              </label> */}
            </div>
          </form>
        </div>
        <div className="right">
          <h3>PAYMENT</h3>
          <form onSubmit={handleSubmit}>
            {/* <div>
              Accepted Card
              <br />
              <img src="image/card1.png" alt="Card 1" width="100" />
              <img src="image/card2.png" alt="Card 2" width="50" />
            </div> */}
            <label>
              Credit card number
              <input
                type="text"
                name="cardNumber"
                placeholder="Enter card number"
                value={paymentDetails.cardNumber}
                onChange={handlePaymentChange}
              />
            </label>
            <label>
              Exp month
              <input
                type="text"
                name="expMonth"
                placeholder="Enter Month"
                value={paymentDetails.expMonth}
                onChange={handlePaymentChange}
              />
            </label>
            <div id="zip">
              <label>
                Exp year
                <select
                  name="expYear"
                  value={paymentDetails.expYear}
                  onChange={handlePaymentChange}
                >
                  <option>Choose Year..</option>
                  <option>2022</option>
                  <option>2023</option>
                  <option>2024</option>
                  <option>2025</option>
                </select>
              </label>
              <label>
                CVV
                <input
                  type="number"
                  name="cvv"
                  placeholder="CVV"
                  value={paymentDetails.cvv}
                  onChange={handlePaymentChange}
                />
              </label>
            </div>
            <button type="submit">Proceed to Checkout</button>
          </form>
        </div>
      </div>
    </header>
  );
};

export default PaymentForm;

