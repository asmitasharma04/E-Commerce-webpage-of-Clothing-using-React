import React, { useEffect } from 'react';
import D1 from './Assets/D1.png';
import D2 from './Assets/D2.png';
import D3 from './Assets/D3.png';
import D12 from './Assets/D12.png';
import D22 from './Assets/D22.png';
import D32 from './Assets/D32.png';

const Services = () => {
  useEffect(() => {
    const handleMouseOver = (event) => {
      const frontImg = event.currentTarget.querySelector('.front-img');
      const rearImg = event.currentTarget.querySelector('.rear-img');
      if (frontImg && rearImg) {
        frontImg.style.visibility = 'hidden';
        rearImg.style.visibility = 'visible';
      }
    };

    const handleMouseOut = (event) => {
      const frontImg = event.currentTarget.querySelector('.front-img');
      const rearImg = event.currentTarget.querySelector('.rear-img');
      if (frontImg && rearImg) {
        frontImg.style.visibility = 'visible';
        rearImg.style.visibility = 'hidden';
      }
    };

    const boxes = document.querySelectorAll('.box');

    boxes.forEach(box => {
      box.addEventListener('mouseover', handleMouseOver);
      box.addEventListener('mouseout', handleMouseOut);
    });

    // Cleanup function to remove event listeners
    return () => {
      boxes.forEach(box => {
        box.removeEventListener('mouseover', handleMouseOver);
        box.removeEventListener('mouseout', handleMouseOut);
      });
    };
  }, []); // Empty dependency array ensures this runs once after the initial render

  return (
    <section id="deliver" className="deliver">
      <h2 style={{ color: '#588C7E', textAlign: 'center', fontStyle: 'bodoni' }}>Services</h2>
      <div className="box-container">
        {[D1, D2, D3].map((img, index) => (
          <div className="box" key={index}>
            <div className="image">
              <img 
                src={img} 
                alt={`Front Image ${index + 1}`} // Correctly interpolate the index
                className="front-img" 
              />
              <img 
                src={[D12, D22, D32][index]} 
                alt={`Rear Image ${index + 1}`} // Correctly interpolate the index
                className="rear-img" 
                style={{ visibility: 'hidden' }} 
              />
            </div>
          </div>
        ))}
        <div className="box content">
          <h3>Feel free to ask</h3>
          <h2>+91 9865109510</h2>
          <p>The service a business provides is something that the customer is unable to perform themselves, so there are a lot of elements to good service delivery.</p>
        </div>
      </div>
      <br></br>
      <br></br>
    </section>
  );
};

export default Services;
