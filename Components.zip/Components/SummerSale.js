import React, { useEffect } from 'react';
import logo from './Assets/summer-sale2.png'; 

function SummerSale() {
  useEffect(() => {
    function countdown() {
      const endDate = new Date("November 10, 2024 23:59:59").getTime();
      const now = new Date().getTime();
      const timeLeft = endDate - now;

      const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

      document.getElementById("days").textContent = days;
      document.getElementById("hours").textContent = hours;
      document.getElementById("minutes").textContent = minutes;
      document.getElementById("seconds").textContent = seconds;
    }

    const intervalId = setInterval(countdown, 1000);
    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div>
      <br></br>
      <br></br>
      <h2 style={{ color: '#588C7E', textAlign: 'center', fontStyle: 'bodon' }}>Summer Sale</h2>
      <section id="special" className="special">
        <div className="container">
          <div className="row row-flex">
            <div className="col-lg-7">
              <div className="countdown-container">
                <h2 className="text-uppercase">Women Floral</h2>
                <p className="my-4">
                  Women’s floral dresses are a delightful fusion of nature's beauty and timeless style, designed to adorn women with elegance and grace.
                </p>
                <ul className="list-unstyled countdown-counter">
                  <li><span id="days">00</span> Days</li>
                  <li><span id="hours">00</span> Hours</li>
                  <li><span id="minutes">00</span> Minutes</li>
                  <li><span id="seconds">00</span> Seconds</li>
                </ul>
                <div className="countdown-price h3">Rs. 1800.00</div>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="special-img position-relative">
                <img src={logo} alt="Sale Image" className="img-fluid" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default SummerSale;